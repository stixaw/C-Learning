private void HelpSetupActivitiesFakes(
            List<Activity> fakeActivity,
            ActivityOutcome fakeOutcome,
            List<ArgumentHierarchy> fakeHierarchy)
        {
            var mockedActivity = RepositoryTestingHelper
                .GetMockDbSet<Activity>(fakeActivity.AsQueryable());

            mockedActivity.Setup(x => x.Include("InputArgument"))
                .Returns(mockedActivity.Object);
            mockedActivity.Setup(x => x.Include("OutputArgument"))
                .Returns(mockedActivity.Object);

            _mockContext.Setup(m => m.Activities)
                .Returns(mockedActivity.Object);

            _mockContext.Setup(m => m.ActivityOutcomes)
                .Returns(RepositoryTestingHelper.GetQueryableMockDbSet(fakeOutcome));

            var hierarchySet = new Mock<DbSet<ArgumentHierarchy>>();
            hierarchySet.Setup(m => m.SqlQuery(It.IsAny<string>(), It.IsAny<object>()))
                .Returns<string, object[]>((sql, param) =>
            {
                var sqlQueryMock = new Mock<DbSqlQuery<ArgumentHierarchy>>();
                sqlQueryMock.Setup(m => m.AsNoTracking())
                    .Returns(sqlQueryMock.Object);
                sqlQueryMock.Setup(m => m.GetEnumerator())
                    .Returns(fakeHierarchy.GetEnumerator());
                return sqlQueryMock.Object;
            });

            _mockContext.Setup(m => m.Set<ArgumentHierarchy>())
                .Returns(hierarchySet.Object);
        }
        
        [TestMethod]
        [TestCategory("UnitTest")]
        public void Activities_WhenTwoActive_ReturnsTwoResults()
        {
            //Arrange
            var fakeActivity = new List<Activity>{ 
                new Activity { 
                    ActivityID = 1
                },
                new Activity{
                    ActivityID = 2
                }
            };
            var fakeOutcome = Fakes.FakeOutcome();

            HelpSetupActivitiesFakes(fakeActivity, fakeOutcome, Fakes.FakeHierarchy());

            //act
            var results = _domainDal.Activities();

            //assert
            Assert.AreEqual(fakeActivity.Count, results.Count);

        }
        
        
    public static class RepositoryTestingHelper
    {
        public static DbSet<T> GetQueryableMockDbSet<T>(params T[] sourceList) where T : class
        {
            var queryable = sourceList.AsQueryable();

            var dbSet = new Mock<DbSet<T>>();
            dbSet.As<IQueryable<T>>().Setup(m => m.Provider).Returns(queryable.Provider);
            dbSet.As<IQueryable<T>>().Setup(m => m.Expression).Returns(queryable.Expression);
            dbSet.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(queryable.ElementType);
            dbSet.As<IQueryable<T>>().Setup(m => m.GetEnumerator()).Returns(queryable.GetEnumerator());

            return dbSet.Object;
        }

        public static Mock<DbSet<T>> GetMockDbSet<T>(IQueryable<T> entities) where T : class
        {
            var mockSet = new Mock<DbSet<T>>();
            mockSet.As<IQueryable<T>>().Setup(m => m.Provider).Returns(entities.Provider);
            mockSet.As<IQueryable<T>>().Setup(m => m.Expression).Returns(entities.Expression);
            mockSet.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(entities.ElementType);
            mockSet.As<IQueryable<T>>().Setup(m => m.GetEnumerator()).Returns(entities.GetEnumerator());
            return mockSet;
        }
    }